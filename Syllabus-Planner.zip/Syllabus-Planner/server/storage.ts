import { db } from "./db";
import {
  courses,
  syllabusItems,
  subtasks,
  type Course,
  type InsertCourse,
  type SyllabusItem,
  type InsertSyllabusItem,
  type Subtask,
  type InsertSubtask,
  type CourseWithItems,
} from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Courses
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<CourseWithItems | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  deleteCourse(id: number): Promise<void>;

  // Syllabus Items
  getSyllabusItem(id: number): Promise<SyllabusItem | undefined>;
  createSyllabusItem(item: InsertSyllabusItem): Promise<SyllabusItem>;
  updateSyllabusItem(id: number, updates: Partial<InsertSyllabusItem>): Promise<SyllabusItem>;
  deleteSyllabusItem(id: number): Promise<void>;

  // Subtasks
  getSubtask(id: number): Promise<Subtask | undefined>;
  createSubtask(subtask: InsertSubtask): Promise<Subtask>;
  updateSubtask(id: number, updates: Partial<InsertSubtask>): Promise<Subtask>;
  deleteSubtask(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getCourses(): Promise<Course[]> {
    return await db.select().from(courses);
  }

  async getCourse(id: number): Promise<CourseWithItems | undefined> {
    const result = await db.query.courses.findFirst({
      where: eq(courses.id, id),
      with: {
        items: {
          with: {
            subtasks: true,
          },
        },
      },
    });
    // @ts-ignore - Drizzle types are complex here but the query matches the structure
    return result;
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const [newCourse] = await db.insert(courses).values(course).returning();
    return newCourse;
  }

  async deleteCourse(id: number): Promise<void> {
    await db.delete(courses).where(eq(courses.id, id));
  }

  async getSyllabusItem(id: number): Promise<SyllabusItem | undefined> {
    const [item] = await db.select().from(syllabusItems).where(eq(syllabusItems.id, id));
    return item;
  }

  async createSyllabusItem(item: InsertSyllabusItem): Promise<SyllabusItem> {
    const [newItem] = await db.insert(syllabusItems).values(item).returning();
    return newItem;
  }

  async updateSyllabusItem(id: number, updates: Partial<InsertSyllabusItem>): Promise<SyllabusItem> {
    const [updated] = await db
      .update(syllabusItems)
      .set(updates)
      .where(eq(syllabusItems.id, id))
      .returning();
    return updated;
  }

  async deleteSyllabusItem(id: number): Promise<void> {
    await db.delete(syllabusItems).where(eq(syllabusItems.id, id));
  }

  async getSubtask(id: number): Promise<Subtask | undefined> {
    const [subtask] = await db.select().from(subtasks).where(eq(subtasks.id, id));
    return subtask;
  }

  async createSubtask(subtask: InsertSubtask): Promise<Subtask> {
    const [newSubtask] = await db.insert(subtasks).values(subtask).returning();
    return newSubtask;
  }

  async updateSubtask(id: number, updates: Partial<InsertSubtask>): Promise<Subtask> {
    const [updated] = await db
      .update(subtasks)
      .set(updates)
      .where(eq(subtasks.id, id))
      .returning();
    return updated;
  }

  async deleteSubtask(id: number): Promise<void> {
    await db.delete(subtasks).where(eq(subtasks.id, id));
  }
}

export const storage = new DatabaseStorage();
