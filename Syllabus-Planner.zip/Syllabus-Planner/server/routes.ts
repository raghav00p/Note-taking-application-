import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { syllabusItems, subtasks } from "@shared/schema";

async function seedDatabase() {
  const courses = await storage.getCourses();
  if (courses.length === 0) {
    const course = await storage.createCourse({
      name: "Introduction to Computer Science",
      color: "#3b82f6",
    });

    const item = await storage.createSyllabusItem({
      courseId: course.id,
      title: "Week 1: Basics of Programming",
      description: "Variables, loops, and functions",
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 1 week from now
      status: "in_progress",
      priority: "high",
    });

    await storage.createSubtask({
      itemId: item.id,
      title: "Watch Lecture 1",
      isCompleted: true,
    });
    
    await storage.createSubtask({
      itemId: item.id,
      title: "Complete Assignment 1",
      isCompleted: false,
    });

    const course2 = await storage.createCourse({
      name: "Calculus I",
      color: "#ef4444",
    });
    
     await storage.createSyllabusItem({
      courseId: course2.id,
      title: "Limits and Continuity",
      description: "Understanding the concept of limits",
      dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
      status: "pending",
      priority: "medium",
    });
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Courses
  app.get(api.courses.list.path, async (req, res) => {
    const courses = await storage.getCourses();
    res.json(courses);
  });

  app.post(api.courses.create.path, async (req, res) => {
    try {
      const input = api.courses.create.input.parse(req.body);
      const course = await storage.createCourse(input);
      res.status(201).json(course);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.get(api.courses.get.path, async (req, res) => {
    const course = await storage.getCourse(Number(req.params.id));
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }
    res.json(course);
  });

  app.delete(api.courses.delete.path, async (req, res) => {
    const course = await storage.getCourse(Number(req.params.id));
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }
    await storage.deleteCourse(Number(req.params.id));
    res.status(204).send();
  });

  // Items
  app.post(api.items.create.path, async (req, res) => {
    try {
      const input = api.items.create.input.parse(req.body);
      const item = await storage.createSyllabusItem(input);
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.put(api.items.update.path, async (req, res) => {
    const id = Number(req.params.id);
    const existing = await storage.getSyllabusItem(id);
    if (!existing) {
      return res.status(404).json({ message: 'Item not found' });
    }
    try {
      const input = api.items.update.input.parse(req.body);
      const updated = await storage.updateSyllabusItem(id, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.items.delete.path, async (req, res) => {
    const id = Number(req.params.id);
    const existing = await storage.getSyllabusItem(id);
    if (!existing) {
      return res.status(404).json({ message: 'Item not found' });
    }
    await storage.deleteSyllabusItem(id);
    res.status(204).send();
  });

  // Subtasks
  app.post(api.subtasks.create.path, async (req, res) => {
    try {
      const input = api.subtasks.create.input.parse(req.body);
      const subtask = await storage.createSubtask(input);
      res.status(201).json(subtask);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.put(api.subtasks.update.path, async (req, res) => {
    const id = Number(req.params.id);
    const existing = await storage.getSubtask(id);
    if (!existing) {
      return res.status(404).json({ message: 'Subtask not found' });
    }
    try {
      const input = api.subtasks.update.input.parse(req.body);
      const updated = await storage.updateSubtask(id, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.subtasks.delete.path, async (req, res) => {
    const id = Number(req.params.id);
    const existing = await storage.getSubtask(id);
    if (!existing) {
      return res.status(404).json({ message: 'Subtask not found' });
    }
    await storage.deleteSubtask(id);
    res.status(204).send();
  });

  // Seed on startup
  seedDatabase().catch(console.error);

  return httpServer;
}
