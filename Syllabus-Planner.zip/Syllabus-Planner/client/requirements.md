## Packages
date-fns | Date formatting for due dates
framer-motion | Smooth animations for lists and cards
lucide-react | Icons (already in base, but emphasizing usage)
react-circular-progressbar | Nice progress visualization

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
