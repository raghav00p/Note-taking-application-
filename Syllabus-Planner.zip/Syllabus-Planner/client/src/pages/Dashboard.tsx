import { useState } from "react";
import { Link } from "wouter";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { 
  useCourses, 
  useDeleteCourse 
} from "@/hooks/use-syllabus";
import { CreateCourseDialog } from "@/components/CreateCourseDialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  BookOpen, 
  Trash2, 
  ArrowRight,
  LayoutGrid,
  List,
  CalendarDays
} from "lucide-react";
import { cn } from "@/lib/utils";

// Unsplash backgrounds for visual interest (subtle academic/abstract themes)
// Using descriptive comments as required
// Abstract geometric blue/white
const HEADER_IMG = "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?q=80&w=2680&auto=format&fit=crop";

export default function Dashboard() {
  const { data: courses, isLoading, error } = useCourses();
  const deleteCourse = useDeleteCourse();
  const [view, setView] = useState<'grid' | 'list'>('grid');

  if (isLoading) {
    return (
      <div className="container mx-auto p-8 space-y-8 max-w-7xl">
        <div className="flex justify-between items-center">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-48 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-screen text-center p-4">
        <h2 className="text-2xl font-bold text-destructive mb-2">Error Loading Dashboard</h2>
        <p className="text-muted-foreground">{error.message}</p>
      </div>
    );
  }

  const handleDelete = (e: React.MouseEvent, id: number) => {
    e.preventDefault();
    e.stopPropagation();
    if (confirm("Delete this course and all its tasks?")) {
      deleteCourse.mutate(id);
    }
  };

  return (
    <div className="min-h-screen bg-background/50">
      {/* Hero Header */}
      <div className="relative h-64 bg-slate-900 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={HEADER_IMG} 
            alt="Dashboard Header" 
            className="w-full h-full object-cover opacity-40 mix-blend-overlay"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
        </div>
        <div className="absolute bottom-0 left-0 right-0 p-8 container mx-auto max-w-7xl">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <p className="text-primary font-medium mb-2 flex items-center gap-2">
                <CalendarDays className="w-4 h-4" />
                {format(new Date(), "EEEE, MMMM do")}
              </p>
              <h1 className="text-4xl md:text-5xl font-display font-bold text-foreground">
                My Syllabus
              </h1>
              <p className="text-muted-foreground mt-2 max-w-xl text-lg">
                Track your progress, manage assignments, and stay ahead of deadlines.
              </p>
            </div>
            <CreateCourseDialog />
          </div>
        </div>
      </div>

      <main className="container mx-auto px-4 sm:px-8 py-8 max-w-7xl">
        {/* View Toggle & Count */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-primary" />
            Active Courses ({courses?.length || 0})
          </h2>
          <div className="flex items-center gap-1 bg-secondary/50 p-1 rounded-lg">
            <Button
              variant={view === 'grid' ? 'secondary' : 'ghost'}
              size="sm"
              onClick={() => setView('grid')}
              className="h-8 w-8 p-0"
            >
              <LayoutGrid className="w-4 h-4" />
            </Button>
            <Button
              variant={view === 'list' ? 'secondary' : 'ghost'}
              size="sm"
              onClick={() => setView('list')}
              className="h-8 w-8 p-0"
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Empty State */}
        {courses?.length === 0 ? (
          <div className="text-center py-20 px-4 border-2 border-dashed border-border rounded-2xl bg-card/50">
            <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-secondary mb-4">
              <BookOpen className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold mb-2">No courses yet</h3>
            <p className="text-muted-foreground max-w-sm mx-auto mb-6">
              Get started by adding your first course to track assignments and deadlines.
            </p>
            <CreateCourseDialog />
          </div>
        ) : (
          <div className={cn(
            "grid gap-6",
            view === 'grid' ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"
          )}>
            {courses?.map((course) => (
              <Link key={course.id} href={`/course/${course.id}`}>
                <motion.div
                  whileHover={{ y: -4, transition: { duration: 0.2 } }}
                  className="h-full cursor-pointer group"
                >
                  <Card className={cn(
                    "h-full overflow-hidden border-border/50 bg-card hover:shadow-xl hover:border-border transition-all duration-300",
                    view === 'list' && "flex flex-row items-center"
                  )}>
                    {/* Color Strip */}
                    <div 
                      className={cn(
                        "transition-all duration-300 group-hover:w-full group-hover:opacity-10",
                        view === 'grid' ? "h-3 w-full" : "w-3 h-full self-stretch"
                      )}
                      style={{ backgroundColor: course.color }}
                    />
                    
                    <div className={cn("flex-1", view === 'list' ? "p-6 flex items-center justify-between" : "")}>
                      <CardHeader className={cn(view === 'list' ? "p-0" : "")}>
                        <div className="flex justify-between items-start">
                          <CardTitle className="font-display text-xl">{course.name}</CardTitle>
                          {view === 'grid' && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity -mr-2 -mt-2"
                              onClick={(e) => handleDelete(e, course.id)}
                            >
                              <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                            </Button>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent className={cn(
                        "text-sm text-muted-foreground",
                        view === 'list' ? "p-0" : "pt-0"
                      )}>
                        <div className="flex items-center gap-2 mt-2">
                          <span className="text-primary font-medium group-hover:translate-x-1 transition-transform inline-flex items-center gap-1">
                            View Syllabus <ArrowRight className="w-3 h-3" />
                          </span>
                        </div>
                      </CardContent>

                      {view === 'list' && (
                         <Button
                         variant="ghost"
                         size="icon"
                         className="ml-4 h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                         onClick={(e) => handleDelete(e, course.id)}
                       >
                         <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                       </Button>
                      )}
                    </div>
                  </Card>
                </motion.div>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
