import { useState, useMemo } from "react";
import { useRoute, Link } from "wouter";
import { useCourse } from "@/hooks/use-syllabus";
import { SyllabusItemCard } from "@/components/SyllabusItemCard";
import { CreateItemDialog } from "@/components/CreateItemDialog";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, SlidersHorizontal, Layers, CheckCircle2 } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function CourseDetails() {
  const [, params] = useRoute("/course/:id");
  const courseId = parseInt(params?.id || "0");
  const { data: course, isLoading, error } = useCourse(courseId);
  
  const [sortBy, setSortBy] = useState<'date' | 'priority'>('date');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'completed'>('all');

  // Computed Stats
  const stats = useMemo(() => {
    if (!course?.items) return { total: 0, completed: 0, progress: 0 };
    const total = course.items.length;
    const completed = course.items.filter(i => i.status === 'completed').length;
    return {
      total,
      completed,
      progress: total === 0 ? 0 : Math.round((completed / total) * 100)
    };
  }, [course]);

  // Filtered & Sorted Items
  const filteredItems = useMemo(() => {
    if (!course?.items) return [];
    
    let items = [...course.items];
    
    // Filter
    if (filterStatus !== 'all') {
      items = items.filter(i => 
        filterStatus === 'completed' 
          ? i.status === 'completed' 
          : i.status !== 'completed'
      );
    }

    // Sort
    items.sort((a, b) => {
      if (sortBy === 'date') {
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      } else {
        const priorityMap = { high: 3, medium: 2, low: 1 };
        return priorityMap[b.priority as keyof typeof priorityMap] - priorityMap[a.priority as keyof typeof priorityMap];
      }
    });

    return items;
  }, [course?.items, sortBy, filterStatus]);

  if (isLoading) {
    return (
      <div className="container mx-auto p-8 max-w-5xl space-y-8">
        <Skeleton className="h-8 w-32 mb-4" />
        <div className="space-y-4">
          <Skeleton className="h-32 w-full rounded-2xl" />
          <Skeleton className="h-64 w-full rounded-2xl" />
        </div>
      </div>
    );
  }

  if (error || !course) {
    return (
      <div className="flex flex-col items-center justify-center h-screen gap-4">
        <h2 className="text-2xl font-bold">Course not found</h2>
        <Link href="/">
          <Button variant="outline">Back to Dashboard</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header with Color Accent */}
      <div className="relative bg-card border-b border-border/50 pb-8 pt-12 px-4 sm:px-8">
        <div 
          className="absolute top-0 left-0 right-0 h-2" 
          style={{ backgroundColor: course.color }} 
        />
        
        <div className="max-w-5xl mx-auto">
          <Link href="/">
            <Button variant="ghost" className="mb-6 pl-0 hover:pl-2 transition-all text-muted-foreground hover:text-foreground">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
            </Button>
          </Link>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="flex-1">
              <h1 className="text-4xl font-display font-bold text-foreground mb-4">
                {course.name}
              </h1>
              
              <div className="flex items-center gap-6 text-sm">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">{stats.total} Items</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                  <span className="text-muted-foreground">{stats.completed} Completed</span>
                </div>
              </div>

              <div className="mt-6 max-w-md">
                <div className="flex justify-between text-xs mb-2">
                  <span className="font-medium">Course Progress</span>
                  <span>{stats.progress}%</span>
                </div>
                <Progress value={stats.progress} className="h-2" />
              </div>
            </div>

            <CreateItemDialog courseId={course.id} />
          </div>
        </div>
      </div>

      <main className="max-w-5xl mx-auto px-4 sm:px-8 py-8">
        {/* Controls Toolbar */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-8 bg-secondary/20 p-4 rounded-xl border border-border/50">
          <div className="flex items-center gap-4 w-full sm:w-auto">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <SlidersHorizontal className="w-4 h-4" /> Filters:
            </div>
            
            <Select value={sortBy} onValueChange={(v: any) => setSortBy(v)}>
              <SelectTrigger className="w-[140px] h-9 bg-background">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">Due Date</SelectItem>
                <SelectItem value="priority">Priority</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterStatus} onValueChange={(v: any) => setFilterStatus(v)}>
              <SelectTrigger className="w-[140px] h-9 bg-background">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Items</SelectItem>
                <SelectItem value="pending">Active</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Syllabus Items List */}
        <div className="space-y-4">
          {filteredItems.length === 0 ? (
            <div className="text-center py-16 px-4 rounded-2xl border-2 border-dashed border-border/60">
              <p className="text-muted-foreground">No syllabus items found matching your filters.</p>
            </div>
          ) : (
            filteredItems.map((item) => (
              <SyllabusItemCard 
                key={item.id} 
                item={item} 
                courseColor={course.color} 
              />
            ))
          )}
        </div>
      </main>
    </div>
  );
}
