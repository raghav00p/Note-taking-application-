import { useState } from "react";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { 
  type SyllabusItem, 
  type Subtask, 
  type InsertSubtask 
} from "@shared/schema";
import { 
  useUpdateSyllabusItem, 
  useDeleteSyllabusItem,
  useCreateSubtask,
  useUpdateSubtask,
  useDeleteSubtask
} from "@/hooks/use-syllabus";
import { useToast } from "@/hooks/use-toast";

import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  ChevronDown, 
  MoreVertical, 
  Calendar as CalendarIcon, 
  Trash2, 
  Plus,
  AlertCircle,
  CheckCircle2,
  Clock
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SyllabusItemCardProps {
  item: SyllabusItem & { subtasks: Subtask[] };
  courseColor: string;
}

export function SyllabusItemCard({ item, courseColor }: SyllabusItemCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState("");
  const { toast } = useToast();

  const updateItem = useUpdateSyllabusItem();
  const deleteItem = useDeleteSyllabusItem();
  const createSubtask = useCreateSubtask();
  const updateSubtask = useUpdateSubtask();
  const deleteSubtask = useDeleteSubtask();

  const completedSubtasks = item.subtasks.filter(s => s.isCompleted).length;
  const totalSubtasks = item.subtasks.length;
  const progress = totalSubtasks === 0 ? 0 : Math.round((completedSubtasks / totalSubtasks) * 100);

  // Status Badge Logic
  const getStatusColor = (status: string) => {
    switch(status) {
      case 'completed': return 'bg-green-100 text-green-700 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-400';
      case 'in_progress': return 'bg-blue-100 text-blue-700 hover:bg-blue-200 dark:bg-blue-900/30 dark:text-blue-400';
      default: return 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-400';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch(priority) {
      case 'high': return <AlertCircle className="w-3 h-3 text-red-500 mr-1" />;
      case 'medium': return <Clock className="w-3 h-3 text-orange-500 mr-1" />;
      default: return <CheckCircle2 className="w-3 h-3 text-blue-500 mr-1" />;
    }
  };

  const handleAddSubtask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubtaskTitle.trim()) return;

    createSubtask.mutate({
      itemId: item.id,
      title: newSubtaskTitle,
      isCompleted: false
    }, {
      onSuccess: () => setNewSubtaskTitle("")
    });
  };

  const handleDeleteItem = () => {
    if (confirm("Are you sure you want to delete this item?")) {
      deleteItem.mutate({ id: item.id, courseId: item.courseId });
    }
  };

  const handleStatusChange = (newStatus: string) => {
    updateItem.mutate({ id: item.id, status: newStatus });
  };

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "group relative bg-card border border-border/50 rounded-xl overflow-hidden transition-all duration-300",
        isExpanded ? "shadow-md ring-1 ring-primary/5" : "hover:shadow-sm hover:border-border"
      )}
    >
      {/* Colored Left Border Accent */}
      <div 
        className="absolute left-0 top-0 bottom-0 w-1.5" 
        style={{ backgroundColor: courseColor }}
      />

      <div className="pl-6 pr-4 py-4">
        {/* Header Row */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 cursor-pointer" onClick={() => setIsExpanded(!isExpanded)}>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-display font-semibold text-lg leading-tight text-foreground">
                {item.title}
              </h3>
              {item.priority === 'high' && (
                <span className="flex h-2 w-2 rounded-full bg-red-500 animate-pulse" />
              )}
            </div>
            
            <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground mt-1.5">
              {item.dueDate && (
                <div className="flex items-center gap-1.5 bg-secondary/50 px-2 py-0.5 rounded-md">
                  <CalendarIcon className="w-3.5 h-3.5" />
                  <span>{format(new Date(item.dueDate), "MMM d, yyyy")}</span>
                </div>
              )}
              
              <div className="flex items-center gap-1.5">
                {getPriorityIcon(item.priority)}
                <span className="capitalize">{item.priority} Priority</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Badge 
                  variant="secondary" 
                  className={cn("cursor-pointer transition-colors", getStatusColor(item.status))}
                >
                  {item.status.replace('_', ' ')}
                </Badge>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => handleStatusChange('pending')}>Pending</DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleStatusChange('in_progress')}>In Progress</DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleStatusChange('completed')}>Completed</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleDeleteItem} className="text-destructive focus:text-destructive">
                  <Trash2 className="mr-2 h-4 w-4" /> Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Progress Bar (Always Visible if subtasks exist) */}
        {totalSubtasks > 0 && (
          <div className="mt-4 flex items-center gap-3">
            <Progress value={progress} className="h-1.5" indicatorClassName="bg-primary/80" />
            <span className="text-xs font-medium text-muted-foreground min-w-[3rem]">
              {progress}%
            </span>
          </div>
        )}
      </div>

      {/* Expandable Content */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="border-t border-border/50 bg-secondary/10"
          >
            <div className="pl-6 pr-4 py-4 space-y-4">
              {item.description && (
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {item.description}
                </p>
              )}

              <div className="space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                  Subtasks ({completedSubtasks}/{totalSubtasks})
                </h4>
                
                {item.subtasks.map((subtask) => (
                  <div key={subtask.id} className="flex items-center gap-3 group/subtask">
                    <Checkbox 
                      checked={subtask.isCompleted}
                      onCheckedChange={(checked) => 
                        updateSubtask.mutate({ id: subtask.id, isCompleted: !!checked })
                      }
                      className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                    />
                    <span className={cn(
                      "text-sm flex-1 transition-all",
                      subtask.isCompleted ? "text-muted-foreground line-through decoration-muted-foreground/50" : "text-foreground"
                    )}>
                      {subtask.title}
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 opacity-0 group-hover/subtask:opacity-100 transition-opacity"
                      onClick={() => deleteSubtask.mutate(subtask.id)}
                    >
                      <Trash2 className="h-3 w-3 text-muted-foreground hover:text-destructive" />
                    </Button>
                  </div>
                ))}

                <form onSubmit={handleAddSubtask} className="flex items-center gap-2 mt-3">
                  <Input 
                    placeholder="Add a subtask..." 
                    value={newSubtaskTitle}
                    onChange={(e) => setNewSubtaskTitle(e.target.value)}
                    className="h-8 text-sm bg-background/50"
                  />
                  <Button 
                    type="submit" 
                    size="sm" 
                    variant="secondary"
                    disabled={!newSubtaskTitle.trim() || createSubtask.isPending}
                    className="h-8 w-8 p-0"
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </form>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Expand Toggle Visual */}
      <div 
        className="absolute bottom-0 left-0 right-0 h-1 bg-transparent group-hover:bg-primary/5 transition-colors cursor-pointer flex justify-center items-center"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <ChevronDown className={cn(
          "w-3 h-3 text-muted-foreground/50 transition-transform duration-300",
          isExpanded ? "rotate-180" : ""
        )} />
      </div>
    </motion.div>
  );
}
